import React from 'react';
import { Component } from 'react';

class PrimaryMessage extends Component {
  render() {
    return (
      <h5>This is primary message</h5>
    );
  }
}

export default PrimaryMessage;